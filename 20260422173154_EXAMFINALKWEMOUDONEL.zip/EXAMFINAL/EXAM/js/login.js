
                        async function submitLogin(event) {
                            event.preventDefault();

                            const form = document.getElementById("loginForm");
                            const msg = document.getElementById("msg");
                            const user = form.user.value.trim();
                            const pw = form.pw.value;

                            if (user === "" || pw.trim() === "") {
                                msg.textContent = "Le userId et le mot de passe sont obligatoires.";
                                return false;
                            }

                            form.user.value = user;
                            const response = await fetch(document.body.dataset.base + "/api/login", {
                                method: "POST",
                                body: new FormData(form)
                            });
                            const result = await response.json();

                            msg.textContent = result.msg;
                            msg.className = result.status === "ok" ? "notice ok" : "notice error";

                            if (result.status === "ok") {
                                window.location.replace(document.body.dataset.base + "/todos");
                            }
                            return false;
                        }
                