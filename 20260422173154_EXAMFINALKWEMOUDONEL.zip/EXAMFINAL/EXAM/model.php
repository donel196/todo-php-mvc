<?php
/* =====================================================
   DATABASE CONNECTION (PDO)
===================================================== */
function db_connect() {

    try {
        $conn = new PDO(
            "mysql:host=localhost;dbname=TODO_DB;charset=utf8mb4",
            "root",
            "root"
        );
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    }
    catch (PDOException $e) {
        throw new PDOException("Connexion à la base de données impossible.");
    }
}

/* =====================================================
   UTILS
===================================================== */
function clean_user($user) {
    return trim($user);
}

function valid_deadline($deadline) {
    return $deadline === '' || preg_match('/^\d{4}-\d{2}-\d{2}$/', $deadline);
}

/* =====================================================
   LOGIN
===================================================== */
function process_login($data) {

    $user = clean_user($data['user'] ?? '');
    $pw   = $data['pw'] ?? '';

    if ($user === '' || trim($pw) === '') {
        return ['status' => 'error', 'msg' => 'Le userId et le mot de passe sont obligatoires.'];
    }

    try {
        $conn = db_connect();
        $stmt = $conn->prepare("SELECT USER, HPW FROM LOGINS WHERE USER = ?");
        $stmt->execute([$user]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row === false || !password_verify($user . $pw, $row['HPW'])) {
            return ['status' => 'error', 'msg' => 'UserId ou mot de passe incorrect.'];
        }

        /* Silent hash upgrade */
        if (password_needs_rehash($row['HPW'], PASSWORD_DEFAULT)) {
            $newHash = password_hash($user . $pw, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE LOGINS SET HPW = ? WHERE USER = ?");
            $stmt->execute([$newHash, $user]);
        }

        return ['status' => 'ok', 'msg' => 'Login correct.', 'user' => $user];
    }
    catch (PDOException $e) {
        return ['status' => 'error', 'msg' => 'Erreur de connexion à la base de données.'];
    }
}

/* =====================================================
   CREATE LOGIN
===================================================== */
function create_login($data) {

    $user   = clean_user($data['user'] ?? '');
    $pw     = $data['pw'] ?? '';
    $confpw = $data['confpw'] ?? '';

    if (strlen($user) < 3) {
        return ['status' => 'error', 'msg' => 'Le userId doit avoir au moins trois caractères.'];
    }
    if (strlen($user) > 30) {
        return ['status' => 'error', 'msg' => 'Le userId doit avoir au maximum 30 caractères.'];
    }
    if (preg_match('/\s/', $user)) {
        return ['status' => 'error', 'msg' => 'Le userId ne doit pas contenir de blanc.'];
    }
    if (strlen($pw) < 3) {
        return ['status' => 'error', 'msg' => 'Le mot de passe doit avoir au moins trois caractères.'];
    }
    if ($pw !== $confpw) {
        return ['status' => 'error', 'msg' => 'La confirmation du mot de passe est différente.'];
    }

    try {
        $conn = db_connect();

        $stmt = $conn->prepare("SELECT USER FROM LOGINS WHERE USER = ?");
        $stmt->execute([$user]);
        if ($stmt->fetch()) {
            return ['status' => 'error', 'msg' => 'Ce userId existe déjà.'];
        }

        $hash = password_hash($user . $pw, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO LOGINS (USER, HPW) VALUES (?, ?)");
        $stmt->execute([$user, $hash]);

        return ['status' => 'ok', 'msg' => 'Login créé. Vous pouvez maintenant vous connecter.'];
    }
    catch (PDOException $e) {
        return ['status' => 'error', 'msg' => 'Création du login impossible.'];
    }
}

/* =====================================================
   CHANGE PASSWORD
===================================================== */
function change_password($data) {

    $user   = clean_user($data['user'] ?? '');
    $oldpw  = $data['oldpw'] ?? '';
    $newpw  = $data['newpw'] ?? '';
    $confpw = $data['confpw'] ?? '';

    if ($user === '' || trim($oldpw) === '') {
        return ['status' => 'error', 'msg' => 'Le userId et le mot de passe courant sont obligatoires.'];
    }
    if (strlen($newpw) < 3) {
        return ['status' => 'error', 'msg' => 'Le nouveau mot de passe doit avoir au moins trois caractères.'];
    }
    if ($newpw !== $confpw) {
        return ['status' => 'error', 'msg' => 'La confirmation du nouveau mot de passe est différente.'];
    }

    try {
        $conn = db_connect();
        $stmt = $conn->prepare("SELECT HPW FROM LOGINS WHERE USER = ?");
        $stmt->execute([$user]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row === false || !password_verify($user . $oldpw, $row['HPW'])) {
            return ['status' => 'error', 'msg' => 'UserId ou mot de passe courant incorrect.'];
        }

        $hash = password_hash($user . $newpw, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE LOGINS SET HPW = ? WHERE USER = ?");
        $stmt->execute([$hash, $user]);

        return ['status' => 'ok', 'msg' => 'Mot de passe changé.'];
    }
    catch (PDOException $e) {
        return ['status' => 'error', 'msg' => 'Changement du mot de passe impossible.'];
    }
}

/* =====================================================
   TODOS
===================================================== */
function get_todos($user) {

    $conn = db_connect();
    $stmt = $conn->prepare(
        "SELECT ID, ACTIVITE, ECHEANCE FROM TODOS WHERE USER = ? ORDER BY ID"
    );
    $stmt->execute([$user]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function process_todo($user, $data) {

    $action   = $data['action'] ?? '';
    $activity = trim($data['activite'] ?? '');
    $deadline = trim($data['echeance'] ?? '');
    $deadlineValue = ($deadline === '') ? null : $deadline;

    if ($action === 'add' || $action === 'update') {
        if ($activity === '') {
            return 'Activité obligatoire.';
        }
        if (strlen($activity) > 150) {
            return 'Activité trop longue.';
        }
        if (!valid_deadline($deadline)) {
            return 'Date échéance invalide.';
        }
    }

    try {
        $conn = db_connect();

        if ($action === 'add') {
            $stmt = $conn->prepare(
                "INSERT INTO TODOS (USER, ACTIVITE, ECHEANCE) VALUES (?, ?, ?)"
            );
            $stmt->execute([$user, $activity, $deadlineValue]);
            return 'Tâche ajoutée.';
        }

        if ($action === 'update') {
            $id = (int)($data['id'] ?? 0);
            $stmt = $conn->prepare(
                "UPDATE TODOS SET ACTIVITE = ?, ECHEANCE = ? WHERE ID = ? AND USER = ?"
            );
            $stmt->execute([$activity, $deadlineValue, $id, $user]);
            return 'Tâche mise à jour.';
        }

        if ($action === 'delete') {
            $id = (int)($data['id'] ?? 0);
            $stmt = $conn->prepare(
                "DELETE FROM TODOS WHERE ID = ? AND USER = ?"
            );
            $stmt->execute([$id, $user]);
            return 'Tâche supprimée.';
        }
    }
    catch (PDOException $e) {
        return 'Opération impossible.';
    }

    return 'Action inconnue.';
}

/* =====================================================
   LOGOUT
===================================================== */
function process_logout() {

    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 72000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_destroy();
    echo '1';
    exit;
}

/* =====================================================
   ESCAPE (XSS)
===================================================== */
function esc($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}