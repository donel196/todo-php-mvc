<?php
/* =====================================================
   FRONT CONTROLLER
   (vu en cours – un seul point d’entrée)
===================================================== */

session_start();
require 'model.php';

/* =====================================================
   BASE DES CHEMINS (CSS / JS)
===================================================== */
$assetBase = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
if ($assetBase === '') {
    $assetBase = '.';
}

/* =====================================================
   ROUTE (PATH_INFO)
===================================================== */
$route = $_SERVER['PATH_INFO'] ?? '';

if ($route === '' || $route === '/') {
    $route = isset($_SESSION['user']) ? '/todos' : '/login';
}

/* =====================================================
   OUTILS
===================================================== */
function go_to($route) {
    header('Location: ' . $_SERVER['SCRIPT_NAME'] . $route);
    exit;
}

function require_user() {
    if (!isset($_SESSION['user'])) {
        go_to('/login');
    }
}

function json_answer($array) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($array, JSON_PRETTY_PRINT);
    exit;
}

/* =====================================================
   ROUTAGE
===================================================== */

/* ---------- LOGIN ---------- */
if ($route === '/login') {

    if (isset($_SESSION['user'])) {
        go_to('/todos');
    }

    include 'view/login.php';
    exit;
}

/* ---------- LOGIN (POST / AJAX) ---------- */
elseif ($route === '/api/login' && $_SERVER['REQUEST_METHOD'] === 'POST') {

    $answer = process_login($_POST);
    if ($answer['status'] === 'ok') {
        $_SESSION['user'] = $answer['user'];
    }
    json_answer($answer);
}

/* ---------- CREATE ACCOUNT ---------- */
elseif ($route === '/create') {

    include 'view/create.php';
    exit;
}

/* ---------- CREATE (POST / AJAX) ---------- */
elseif ($route === '/api/create' && $_SERVER['REQUEST_METHOD'] === 'POST') {

    json_answer(create_login($_POST));
}

/* ---------- CHANGE PASSWORD ---------- */
elseif ($route === '/change') {

    include 'view/change.php';
    exit;
}

/* ---------- CHANGE (POST / AJAX) ---------- */
elseif ($route === '/api/change' && $_SERVER['REQUEST_METHOD'] === 'POST') {

    json_answer(change_password($_POST));
}

/* ---------- TODOS (PAGE PRINCIPALE) ---------- */
elseif ($route === '/todos') {

    require_user();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $_SESSION['msg'] = process_todo($_SESSION['user'], $_POST);
        go_to('/todos');
    }

    $rows = get_todos($_SESSION['user']);
    $msg  = $_SESSION['msg'] ?? '';
    unset($_SESSION['msg']);

    include 'view/todos.php';
    exit;
}

/* ---------- LOGOUT ---------- */
elseif ($route === '/api/logout' && $_SERVER['REQUEST_METHOD'] === 'POST') {

    process_logout();
}

/* ---------- ROUTE INCONNUE ---------- */
else {
    http_response_code(404);
    echo '404 - route inconnue';
}


?>
