
<?php
echo password_hash("KWEMOUDONEL123", PASSWORD_DEFAULT);
