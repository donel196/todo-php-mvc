<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Login - To-Do List</title>
    <link rel="stylesheet" href="<?php echo esc($assetBase); ?>/css/style.css">
     <script src="js/login.js"></script>
</head>
<body data-base="<?php echo esc($_SERVER['SCRIPT_NAME']); ?>">
    <main class="loginBox">
        <h1>Login</h1>
        <form id="loginForm" method="post" action="<?php echo esc($_SERVER['SCRIPT_NAME']); ?>/api/login" onsubmit="return submitLogin(event)">
            <label for="user">UserId</label>
            <input type="text" id="user" name="user" maxlength="30" required>

            <label for="pw">Mot de passe</label>
            <input type="password" id="pw" name="pw" required>

            <input type="submit" value="Login">
        </form>

        <p class="links">
            <a href="<?php echo esc($_SERVER['SCRIPT_NAME']); ?>/create">Creer un login</a>
            <a href="<?php echo esc($_SERVER['SCRIPT_NAME']); ?>/change">Changer le mot de passe</a>
        </p>
        <p id="msg" class="notice error"></p>
    </main>
</body>
</html>
