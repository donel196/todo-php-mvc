<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>To-Do List</title>
    <link rel="stylesheet" href="<?php echo esc($assetBase); ?>/css/style.css">
    <script>
        function validateTask(form) {
            const button = document.activeElement;
            if (button && button.name === "action" && button.value === "delete") {
                return true;
            }

            const activity = form.activite.value.trim();
            form.activite.value = activity;

            if (activity === "") {
                alert("Activite obligatoire.");
                return false;
            }
            if (activity.length > 150) {
                alert("Maximum 150 caracteres.");
                return false;
            }
            return true;
        }

        function confirmDelete() {
            return confirm("Delete this activity ?");
        }

       
            async function logout() {
                try {
                    const response = await fetch(
                        document.body.dataset.base + "/api/logout",
                        { method: "POST" }
                    );

                    const result = await response.text();

                    if (result.trim() === "1") {
                        window.location.replace(
                            document.body.dataset.base + "/login"
                        );
                    }
                }
                catch (e) {
                    alert("Erreur lors du logout.");
                }
            }
</script>
    </script>
</head>
<body data-base="<?php echo esc($_SERVER['SCRIPT_NAME']); ?>">
    <button type="button" class="logout" onclick="logout()">logout</button>

    <main class="todoPage">
        <h1>To-Do List</h1>
        <p class="userLine">Utilisateur connecte : <?php echo esc($_SESSION['user']); ?></p>

        <?php if ($msg !== ''): ?>
            <p class="notice ok"><?php echo esc($msg); ?></p>
        <?php endif; ?>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Activity</th>
                    <th>Deadline</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <form method="post" action="<?php echo esc($_SERVER['SCRIPT_NAME']); ?>/todos" onsubmit="return validateTask(this)">
                        <td>(Auto)</td>
                        <td><input type="text" name="activite" maxlength="150" placeholder="New activity" required></td>
                        <td><input type="date" name="echeance"></td>
                        <td><button type="submit" name="action" value="add" class="btn-add">Add</button></td>
                    </form>
                </tr>

                <?php foreach ($rows as $row): ?>
                    <tr>
                        <form method="post" action="<?php echo esc($_SERVER['SCRIPT_NAME']); ?>/todos" onsubmit="return validateTask(this)">
                            <td>
                                <?php echo esc($row['ID']); ?>
                                <input type="hidden" name="id" value="<?php echo esc($row['ID']); ?>">
                            </td>
                            <td><input type="text" name="activite" maxlength="150" value="<?php echo esc($row['ACTIVITE']); ?>" required></td>
                            <td><input type="date" name="echeance" value="<?php echo esc($row['ECHEANCE']); ?>"></td>
                            <td>
                                <button type="submit" name="action" value="update" class="btn-update">Update</button>
                                <button type="submit" name="action" value="delete" class="btn-delete" onclick="return confirmDelete()">Delete</button>
                            </td>
                        </form>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </main>
</body>
</html>
