<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Creation de login</title>
    <link rel="stylesheet" href="<?php echo esc($assetBase); ?>/css/style.css">
    <script>
        async function submitCreate(event) {
            event.preventDefault();

            const form = document.getElementById("createForm");
            const msg = document.getElementById("msg");
            const user = form.user.value.trim();

            if (user.length < 3) {
                msg.textContent = "Le userId doit avoir au moins trois caracteres.";
                return false;
            }
            if (/\s/.test(user)) {
                msg.textContent = "Le userId ne doit pas contenir de blanc.";
                return false;
            }
            if (form.pw.value.length < 3) {
                msg.textContent = "Le mot de passe doit avoir au moins trois caracteres.";
                return false;
            }
            if (form.pw.value !== form.confpw.value) {
                msg.textContent = "Les mots de passe doivent etre identiques.";
                return false;
            }

            form.user.value = user;
            const response = await fetch(document.body.dataset.base + "/api/create", {
                method: "POST",
                body: new FormData(form)
            });
            const result = await response.json();

            msg.textContent = result.msg;
            msg.className = result.status === "ok" ? "notice ok" : "notice error";
            if (result.status === "ok") {
                form.reset();
            }
            return false;
        }
    </script>
</head>
<body data-base="<?php echo esc($_SERVER['SCRIPT_NAME']); ?>">
    <main class="loginBox">
        <h1>Creer un login</h1>
        <form id="createForm" method="post" action="<?php echo esc($_SERVER['SCRIPT_NAME']); ?>/api/create" onsubmit="return submitCreate(event)">
            <label for="user">UserId</label>
            <input type="text" id="user" name="user" maxlength="30" required>

            <label for="pw">Mot de passe</label>
            <input type="password" id="pw" name="pw" required>

            <label for="confpw">Confirmer le mot de passe</label>
            <input type="password" id="confpw" name="confpw" required>

            <input type="submit" value="Creer">
        </form>

        <p class="links"><a href="<?php echo esc($_SERVER['SCRIPT_NAME']); ?>/login">Retour au login</a></p>
        <p id="msg" class="notice error"></p>
    </main>
</body>
</html>
