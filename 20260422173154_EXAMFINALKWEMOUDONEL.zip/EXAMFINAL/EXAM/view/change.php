<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Changement de mot de passe</title>
    <link rel="stylesheet" href="<?php echo esc($assetBase); ?>/css/style.css">
    <script>
        async function submitChange(event) {
            event.preventDefault();

            const form = document.getElementById("changeForm");
            const msg = document.getElementById("msg");
            const user = form.user.value.trim();

            if (user === "" || form.oldpw.value.trim() === "") {
                msg.textContent = "Le userId et le mot de passe courant sont obligatoires.";
                return false;
            }
            if (form.newpw.value.length < 3) {
                msg.textContent = "Le nouveau mot de passe doit avoir au moins trois caracteres.";
                return false;
            }
            if (form.newpw.value !== form.confpw.value) {
                msg.textContent = "La confirmation du nouveau mot de passe est differente.";
                return false;
            }

            form.user.value = user;
            const response = await fetch(document.body.dataset.base + "/api/change", {
                method: "POST",
                body: new FormData(form)
            });
            const result = await response.json();

            msg.textContent = result.msg;
            msg.className = result.status === "ok" ? "notice ok" : "notice error";
            if (result.status === "ok") {
                form.reset();
            }
            return false;
        }
    </script>
</head>
<body data-base="<?php echo esc($_SERVER['SCRIPT_NAME']); ?>">
    <main class="loginBox">
        <h1>Changer le mot de passe</h1>
        <form id="changeForm" method="post" action="<?php echo esc($_SERVER['SCRIPT_NAME']); ?>/api/change" onsubmit="return submitChange(event)">
            <label for="user">UserId</label>
            <input type="text" id="user" name="user" maxlength="30" required>

            <label for="oldpw">Mot de passe courant</label>
            <input type="password" id="oldpw" name="oldpw" required>

            <label for="newpw">Nouveau mot de passe</label>
            <input type="password" id="newpw" name="newpw" required>

            <label for="confpw">Confirmer le nouveau mot de passe</label>
            <input type="password" id="confpw" name="confpw" required>

            <input type="submit" value="Changer">
        </form>

        <p class="links"><a href="<?php echo esc($_SERVER['SCRIPT_NAME']); ?>/login">Retour au login</a></p>
        <p id="msg" class="notice error"></p>
    </main>
</body>
</html>
